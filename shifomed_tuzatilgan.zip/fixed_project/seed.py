import os
import django

# Setup django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'hospital_system.settings')
django.setup()

from booking.models import Department, Doctor
from django.contrib.auth.models import User

# Create superuser
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser('admin', 'admin@example.com', 'admin123')
    print("Superuser created!")

# Clear existing simple data
Department.objects.all().delete()
Doctor.objects.all().delete()

# Create Departments
d1 = Department.objects.create(name='Kardiologiya', description='Yurak va qon tomir kasalliklari', icon='fa-solid fa-heart-pulse')
d2 = Department.objects.create(name='Nevrologiya', description='Asab tizimi kasalliklari', icon='fa-solid fa-brain')
d3 = Department.objects.create(name='Stomatologiya', description='Tish va og\'iz bo\'shlig\'i', icon='fa-solid fa-tooth')

# Create Doctors
Doctor.objects.create(
    department=d1, name='Anvarjon Aliyev', bio='15 yillik tajribaga ega Oliy toifali kardiolog.',
    work_start='09:00:00', work_end='15:00:00', slot_duration=30
)
Doctor.objects.create(
    department=d1, name='Dilshod Rustamov', bio='Qon tomir kasalliklari bo\'yicha mutaxassis.',
    work_start='10:00:00', work_end='18:00:00', slot_duration=45
)
Doctor.objects.create(
    department=d2, name='Malika Karimova', bio='Bolalar va kattalar nevropatologi.',
    work_start='09:00:00', work_end='17:00:00', slot_duration=30
)
Doctor.objects.create(
    department=d3, name='Jasur Qodirov', bio='Bugungi kun zamonaviy stomatologiya mutaxassisi.',
    work_start='08:30:00', work_end='14:00:00', slot_duration=60
)

print("Mock data seeded successfully!")
