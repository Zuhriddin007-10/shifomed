#!/usr/bin/env bash
# exit on error
set -o errexit

pip install -r requirements.txt

# ✅ FIX 6: collectstatic to'g'ri ishlaydi (STATIC_ROOT bor)
python manage.py collectstatic --no-input

python manage.py migrate

# ✅ Ixtiyoriy: demo ma'lumotlar
# python manage.py seed
