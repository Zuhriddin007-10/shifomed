from django.contrib import admin
from .models import Department, Doctor, Appointment

@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'icon')
    search_fields = ('name',)

@admin.register(Doctor)
class DoctorAdmin(admin.ModelAdmin):
    list_display = ('name', 'department', 'work_start', 'work_end')
    list_filter = ('department',)
    search_fields = ('name',)

@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('patient_name', 'phone_number', 'doctor', 'date', 'time_slot', 'status')
    list_filter = ('status', 'date', 'doctor')
    search_fields = ('patient_name', 'phone_number')
